#Athur Belal Hossain 
#copyright Belal Hossain 
#Date 09.04.2025

import rasterio
from rasterio.features import rasterize
import geopandas as gpd
import numpy as np
import matplotlib.pyplot as plt

raster_path = "dop20rgb_386_5826_2022_grid_111.tif"
bounds = gpd.read_file("dop20rgb_386_5826_2022_bounds_grid-111.shp")
buildings = gpd.read_file("dop20rgb_386_5826_2022_buildings_grid-111.shp")
markings = gpd.read_file("dop20rgb_386_5826_2022_markings_grid-111.shp")
raster = rasterio.open(raster_path)
raster_meta = raster.meta
height, width = raster.height, raster.width
transform = raster.transform

#color mapping 

features = []

#for bounds
for geom in bounds.geometry:
    features.append((geom, (0, 0, 200)))

#for Buildings
for geom in buildings.geometry:
    features.append((geom, (255, 0, 0)))

# for  markings
print("Marking columns:", markings.columns)
if 'type' not in markings.columns:
    
    for col in markings.columns:
        print("Checking column:", col)

# Map types to colors
marking_colors = {
    'broken line': (0, 20, 10),
    'cycle lane': (0, 40, 0),
    'dashed line': (0, 45, 70),
    'pedestrian crossing': (0, 100, 0),
    'solid line': (0, 45, 0),
    'stop line': (0, 85, 0),
}

# Add markings with perfect color
for _, row in markings.iterrows():
    mark_type = row.get('type') or row.get('Type') or row.get('TYPE')
    color = marking_colors.get(str(mark_type).lower())
    if color:
        features.append((row.geometry, color))

# Rasterize every channel separately

def rasterize_channel(index):
    return rasterize(
        [(geom, color[index]) for geom, color in features],
        out_shape=(height, width),
        transform=transform,
        fill=0,
        dtype=np.uint8
    )

red = rasterize_channel(0)
green = rasterize_channel(1)
blue = rasterize_channel(2)

rgb_mask = np.stack([red, green, blue], axis=-1)


plt.figure(figsize=(10, 10))
plt.imshow(rgb_mask)
plt.title("RGB Mask from Vector Data")
plt.axis("off")
plt.show()

